#ifndef CURRENTTIME_H
#define CURRENTTIME_H

void getCurrentTime(void);

int getHours(void);
int getMins(void);
int getSecs(void);

#endif /* CURRENTTIME_H */
